package com.itheima.domain.query;

import com.itheima.domain.User;
import lombok.Data;

@Data
public class UserQuery extends User {
    private Integer age2;
}
