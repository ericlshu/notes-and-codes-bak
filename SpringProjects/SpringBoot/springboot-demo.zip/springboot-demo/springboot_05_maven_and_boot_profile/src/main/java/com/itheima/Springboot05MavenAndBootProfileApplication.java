package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot05MavenAndBootProfileApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot05MavenAndBootProfileApplication.class, args);
    }

}
