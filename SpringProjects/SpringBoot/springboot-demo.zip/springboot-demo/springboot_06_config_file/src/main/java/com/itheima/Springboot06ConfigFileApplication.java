package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot06ConfigFileApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot06ConfigFileApplication.class, args);
    }

}
