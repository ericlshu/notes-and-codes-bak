package com.itheima.service;

public interface BookService {
    public void save();
}
