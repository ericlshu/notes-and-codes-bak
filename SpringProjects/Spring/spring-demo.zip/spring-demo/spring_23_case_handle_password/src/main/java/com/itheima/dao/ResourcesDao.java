package com.itheima.dao;

public interface ResourcesDao {

    boolean readResources(String url, String password);
}
