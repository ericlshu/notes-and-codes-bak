package com.itheima.dao;

public interface BookDao {
    public String findName(int id,String password);
}
