package com.itheima.dao;

public interface OrderDao {
    public void save();
}
