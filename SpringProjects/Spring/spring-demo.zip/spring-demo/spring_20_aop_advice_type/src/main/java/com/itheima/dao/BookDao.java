package com.itheima.dao;

public interface BookDao {
    public void update();

    public int select();
}
