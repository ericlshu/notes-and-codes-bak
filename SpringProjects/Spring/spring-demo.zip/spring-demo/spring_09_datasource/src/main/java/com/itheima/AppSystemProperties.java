package com.itheima;

public class AppSystemProperties {
    public static void main(String[] args) {

    }
}
