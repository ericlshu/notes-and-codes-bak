package com.hmdp.utils;

public class RedisConstants {

}
