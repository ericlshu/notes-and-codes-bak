package com.hmdp.dto;

import lombok.Data;

@Data
public class UserDTO {
    private Long userId;
    private String nickName;
    private String icon;
}
