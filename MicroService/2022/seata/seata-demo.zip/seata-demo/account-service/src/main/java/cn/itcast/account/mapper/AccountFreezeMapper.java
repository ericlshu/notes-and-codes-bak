package cn.itcast.account.mapper;

import cn.itcast.account.entity.AccountFreeze;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author 虎哥
 */
public interface AccountFreezeMapper extends BaseMapper<AccountFreeze> {
}
