package cn.itcast.order.mapper;

import cn.itcast.order.entity.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author 虎哥
 */
public interface OrderMapper extends BaseMapper<Order> {
}
