
class StrTools:
    pass

str_tool = StrTools()






