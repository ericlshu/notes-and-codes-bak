"""
演示字符串大小比较
"""

# abc 比较 abd
print(f"abd大于abc，结果：{'abd' > 'abc'}")
# a 比较 ab
print(f"ab大于a，结果：{'ab' > 'a'}")
# a 比较 A
print(f"a 大于 A，结果：{'a' > 'A'}")
# key1 比较 key2
print(f"key2 > key1，结果：{'key2' > 'key1'}")
