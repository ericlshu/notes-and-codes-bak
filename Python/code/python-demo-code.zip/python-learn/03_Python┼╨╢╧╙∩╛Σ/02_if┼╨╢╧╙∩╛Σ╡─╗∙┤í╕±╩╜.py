"""
演示Python判断语句：if语句的基本格式应用
"""
age = 10

if age >= 18:
    print("我已经成年了")
    print("即将步入大学生活")

print("时间过的真快呀")

