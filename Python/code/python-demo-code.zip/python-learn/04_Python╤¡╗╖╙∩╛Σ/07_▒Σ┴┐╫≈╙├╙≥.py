"""
演示Python for循环临时变量的作用域
"""
i = 0
for i in range(5):
    print(i)

print(i)

