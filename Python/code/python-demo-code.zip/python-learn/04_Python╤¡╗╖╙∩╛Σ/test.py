
# print("Hello", end='')
# print("world", end='')

print("Hello\tWorld")
print("itheima\tbest")
