import re
s = "itheima1 @@python2 !!666 ##itcast3"
print(re.findall(r'[itc]', s))


def func():

    func()

    return ...
